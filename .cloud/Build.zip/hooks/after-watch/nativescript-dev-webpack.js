module.exports = require("nativescript-dev-webpack/lib/after-watch.js");
