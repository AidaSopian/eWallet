module.exports = require("nativescript-angular/hooks/before-livesync");
